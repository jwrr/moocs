// HelloWorld.java
// javac HelloWorld.java
// java HelloWorld

class HelloWorld
{
  public static void main(String args[])
  {
    System.out.println("Hello, World");
  }
}
